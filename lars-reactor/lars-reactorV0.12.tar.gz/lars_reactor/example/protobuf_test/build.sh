#!/bin/bash
protoc --cpp_out=. ./*.proto
