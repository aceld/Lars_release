#include <iostream>


void lars_hello() 
{
    std::cout <<"lars hello" <<std::endl; 
}
