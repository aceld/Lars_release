#pragma once
#include <stdio.h>

inline void lars_report_logo()
{
    //printf("----------------------------------------------------------\n");
    printf("\n");
    printf("        ▄▄                                               \n");
    printf("        ██                                               \n");
    printf("        ██         ▄█████▄   ██▄████  ▄▄█████▄           \n");
    printf("        ██         ▀ ▄▄▄██   ██▀      ██▄▄▄▄ ▀           \n");
    printf("        ██        ▄██▀▀▀██   ██        ▀▀▀▀██▄           \n");
    printf("        ██▄▄▄▄▄▄  ██▄▄▄███   ██       █▄▄▄▄▄██           \n");
    printf("        ▀▀▀▀▀▀▀▀   ▀▀▀▀ ▀▀   ▀▀        ▀▀▀▀▀▀            \n");
    printf("    Load balance And Remote service schedule System \n");
    printf("                                                         \n");
    printf("        _____                       _                       \n");
    printf("       |  __ \\                     | |\n");
    printf("       | |__) |___ _ __   ___  _ __| |_ ___ _ __\n");
    printf("       |  _  // _ \\ '_ \\ / _ \\| '__| __/ _ \\ '__|\n");
    printf("       | | \\ \\  __/ |_) | (_) | |  | ||  __/ |\n");
    printf("       |_|  \\_\\___| .__/ \\___/|_|   \\__\\___|_|\n");
    printf("                  | |\n");
    printf("                  |_|\n");
    printf("\n");
    printf("            ITCAST(https://www.itcast.cn)\n");
    printf("         ------------------------------------ \n");
    printf("\n");
}
