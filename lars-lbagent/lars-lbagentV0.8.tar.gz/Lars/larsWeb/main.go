package main

import (
	_ "larsWeb/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

