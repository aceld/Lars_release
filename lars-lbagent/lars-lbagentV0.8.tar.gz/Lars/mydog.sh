#!/bin/bash

pro_path=/home/itheima/myshell/awk_test/mytest/
proname=mypro
pid=

is_run()
{
    flag=`ps aux|grep $proname | grep -v grep| wc -l`
    if [ $flag -eq 1 ]; then
        #已经启动
        return 0
    else
        #未启动
        return 1
    fi
    #如果大于1 要杀死全部的进程
}


#看守守护一个进程保活

#1 要判断mypro是否已经启动了
is_run
if [ $? -eq 0 ];then
    #如果启动，记录进程号
    pid=`ps aux|grep mypro | grep -v grep| awk '{print $2}'`
else
    #如果没启动，启动，记录进程号
    $pro_path$proname &
    pid=`ps aux|grep mypro | grep -v grep| awk '{print $2}'`
fi

#2 维护该进程
while [ : ]; do
    if [ -d /proc/$pid ]; then
        echo "进程依然存活，很健康 pid = $pid"
    else
        echo "进程已经死亡，需要重启"
        $pro_path$proname &
        pid=`ps aux|grep mypro | grep -v grep| awk '{print $2}'`
    fi
    sleep 1
done
