#pragma once
#include <stdio.h>

inline void lars_dns_logo()
{
    //printf("----------------------------------------------------------\n");
    printf("\n");
    printf("        ▄▄                                               \n");
    printf("        ██                                               \n");
    printf("        ██         ▄█████▄   ██▄████  ▄▄█████▄           \n");
    printf("        ██         ▀ ▄▄▄██   ██▀      ██▄▄▄▄ ▀           \n");
    printf("        ██        ▄██▀▀▀██   ██        ▀▀▀▀██▄           \n");
    printf("        ██▄▄▄▄▄▄  ██▄▄▄███   ██       █▄▄▄▄▄██           \n");
    printf("        ▀▀▀▀▀▀▀▀   ▀▀▀▀ ▀▀   ▀▀        ▀▀▀▀▀▀            \n");
    printf("    Load balance And Remote service schedule System \n");
    printf("                                                         \n");
    printf("                _____ \n");
    printf("               |  __ \\ \n");
    printf("               | |  | |_ __  ___ \n");
    printf("               | |  | | '_ \\/ __|\n");
    printf("               | |__| | | | \\__ \\ \n");
    printf("               |_____/|_| |_|___/ \n");
    printf("\n");
    printf("            ITCAST(https://www.itcast.cn)\n");
    printf("         ------------------------------------ \n");
    printf("\n");
}
