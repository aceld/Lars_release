#pragma once
#include <stdio.h>

inline void lars_lbagent_logo()
{
    //printf("----------------------------------------------------------\n");
    printf("\n");
    printf("        ▄▄                                               \n");
    printf("        ██                                               \n");
    printf("        ██         ▄█████▄   ██▄████  ▄▄█████▄           \n");
    printf("        ██         ▀ ▄▄▄██   ██▀      ██▄▄▄▄ ▀           \n");
    printf("        ██        ▄██▀▀▀██   ██        ▀▀▀▀██▄           \n");
    printf("        ██▄▄▄▄▄▄  ██▄▄▄███   ██       █▄▄▄▄▄██           \n");
    printf("        ▀▀▀▀▀▀▀▀   ▀▀▀▀ ▀▀   ▀▀        ▀▀▀▀▀▀            \n");
    printf("    Load balance And Remote service schedule System \n");
    printf("                                                         \n");
    printf("      _      _                                _  \n"); 
    printf("     | |    | |         /\\                   | | \n"); 
    printf("     | |    | |__      /  \\   __ _  ___ _ __ | |_ \n");
    printf("     | |    | '_ \\    / /\\ \\ / _` |/ _ \\ '_ \\| __| \n");
    printf("     | |____| |_) |  / ____ \\ (_| |  __/ | | | |_ \n");
    printf("     |______|_.__/  /_/    \\_\\__, |\\___|_| |_|\\__| \n");
    printf("                              __/ | \n"); 
    printf("                             |___/  \n");
    printf("\n");
    printf("            ITCAST(https://www.itcast.cn)\n");
    printf("         ------------------------------------ \n");
    printf("\n");
}
